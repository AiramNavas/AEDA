#include "modificacion_d.h"

Modificacion_D::Modificacion_D()
{}


Modificacion_D::~Modificacion_D()
{}


unsigned int Modificacion_D::dispersion(const DNI& dni, int i) const
{
	return 0;
}

